<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'mg_carbone' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '[RV{jG#xN9b!*OYp.`&93 EIb&S!N4&-`n+/b5ZWOWf.%Pe#];>[FwKV-n-tH&R ' );
define( 'SECURE_AUTH_KEY',  'vRvOG_5uC:4s)v;|F8zJ*aow#c6o6`%!UO$|IJP|HrvJzLka!Y.yN+EiXG3pV%1t' );
define( 'LOGGED_IN_KEY',    'V5iX8T8[3~hHC<7#RgXwH~m= H(yxpkeUa+.TP}<wA3*daDKNIVq&[}sk+EYz#AO' );
define( 'NONCE_KEY',        'e H@+x:8)i%DOb_HQa&Zqe@lv>`sGdC1M e6[8z3MVOydTail HIoQi50;Q&HF#0' );
define( 'AUTH_SALT',        'C2]Pl7o>LT7i>&T=%-%(<U~Rn4 86e/%<Mv/;izs,;t3PZ9b%|4Y[Y$ EL}QRsv!' );
define( 'SECURE_AUTH_SALT', '5y9{)cpt+E:cwM14N@CkF&8 44>7Tv1P7~_)?@D,$S6-TH#Pj>s}NFkNMA0FTo+o' );
define( 'LOGGED_IN_SALT',   'K:HcV5wtb$mC,w=YG1*Mx>5-L5&]OT=1{WhUO=]n|E4A@`WKA-G%~J|X@18Gcxzo' );
define( 'NONCE_SALT',       'lHsGQu6s9#)3>u=-Gz_&4b`4j$KsQ~6/#0ec[kK.n$=O|6P>BmAb$B{pj4l%&[)*' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpmg_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
